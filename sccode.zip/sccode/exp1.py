r"""
Practical 1: Fuzzy Inference System (FIS) - Fan Speed Control

AIM:
    To build a simple Fuzzy Inference System that decides the fan speed
    (LOW / MEDIUM / HIGH) from the room temperature.

THEORY (in simple words):
    - In normal (crisp) logic a thing is either TRUE (1) or FALSE (0).
      Fuzzy logic allows "partly true", i.e. any value between 0 and 1.
      Example: 25 degrees is "a little low" AND "a little medium".
    - A Fuzzy Inference System has 4 steps:
        1. Fuzzification   : turn the crisp input (e.g. 25) into fuzzy
                             values using membership functions.
        2. Rule Base       : IF-THEN rules, e.g.
                             IF temp is High   THEN fan is Fast
                             IF temp is Medium THEN fan is Medium
                             IF temp is Low    THEN fan is Slow
        3. Inference       : check which rule is the strongest.
        4. Defuzzification : turn the fuzzy result back into one clear
                             answer (here: LOW / MEDIUM / HIGH).

HOW THE CODE WORKS:
    - low(), medium(), high() are membership functions. Each one returns
      a number from 0 to 1 that says "how much" the temperature belongs
      to that group.
          Low    : full (1) up to 20, falls to 0 at 30
          Medium : rises from 20 to 30, falls back to 0 at 40
          High   : 0 up to 30, rises to full (1) at 40
    - We read a temperature, find its 3 membership values, and then
      pick the group with the biggest value as the fan speed.

HOW TO RUN (Windows):
    1. Save this code as exp1.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp1.py
    Note:
      - It asks you to type a temperature, e.g. 35

CONCLUSION:
    The Fuzzy Inference System was implemented successfully. It used
    fuzzification, simple IF-THEN rules and defuzzification to choose
    the correct fan speed for the given temperature.
"""
import numpy as np


# ---------- Membership Functions (Fuzzification) ----------
# Each function tells how much (0 to 1) the temperature is Low / Medium / High.

def low(temp):
    if temp <= 20:
        return 1                    # fully "Low"
    elif 20 < temp < 30:
        return (30 - temp) / 10     # slowly becomes less "Low"
    else:
        return 0                    # not "Low" at all


def medium(temp):
    if 20 < temp < 30:
        return (temp - 20) / 10     # rising side of the triangle
    elif 30 <= temp < 40:
        return (40 - temp) / 10     # falling side of the triangle
    else:
        return 0


def high(temp):
    if temp <= 30:
        return 0                    # not "High" at all
    elif 30 < temp < 40:
        return (temp - 30) / 10     # slowly becomes more "High"
    else:
        return 1                    # fully "High"


# Take the crisp input from the user
temperature = float(input("Enter Temperature: "))

# Fuzzify: find the membership value in every group
low_value = low(temperature)
medium_value = medium(temperature)
high_value = high(temperature)

print("Membership Values")
print("Low =", round(low_value, 2))
print("Medium =", round(medium_value, 2))
print("High =", round(high_value, 2))

# Rules + Defuzzification: the group with the largest value wins
if high_value >= max(low_value, medium_value):
    print("Fan Speed : HIGH")
elif medium_value >= low_value:
    print("Fan Speed : MEDIUM")
else:
    print("Fan Speed : LOW")
