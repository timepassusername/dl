r"""
Practical 9: Hopfield Neural Network (Associative Memory)

AIM:
    To implement a Hopfield Network that stores patterns and recalls
    the correct stored pattern from a noisy input.

THEORY (in simple words):
    - A Hopfield Network is a RECURRENT network: every neuron is
      connected to every other neuron, and the output is fed back in
      again and again.
    - It works as ASSOCIATIVE MEMORY: give it a damaged or noisy
      pattern and it "remembers" the closest stored pattern, just like
      you recognise a friend's face even in a blurry photo.
    - Neuron states are bipolar: +1 = active, -1 = inactive.
    - Storing patterns (weight matrix):
          W = sum of (X^T * X) for every pattern
          W[i][i] = 0   (no neuron connects to itself)
    - Recalling a pattern:
          net_i = sum of W[i][j] * X[j]
          X_i   = +1 if net_i >= 0, else -1
      Keep updating until the state stops changing (stable state).

HOW THE CODE WORKS:
    - Two 4-neuron patterns are stored: [1, 1, -1, -1] and its opposite.
    - np.outer(pattern, pattern) builds X^T * X for each pattern; we add
      them up and set the diagonal to 0.
    - The noisy input [1, -1, -1, -1] differs from the first stored
      pattern in one position.
    - In a loop we compute sign(W . state), turning any 0 into +1, and
      stop as soon as the new state equals the old one.
    - The network corrects the noise and recalls [1, 1, -1, -1].

HOW TO RUN (Windows):
    1. Save this code as exp9.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp9.py

CONCLUSION:
    The Hopfield Network was implemented successfully. It stored the
    given patterns and, by updating the neuron states until they became
    stable, recalled the correct stored pattern from a noisy input.
"""
import numpy as np

# Training patterns to store (bipolar: +1 / -1)
patterns = np.array([
    [1, 1, -1, -1],
    [-1, -1, 1, 1]
])

# Number of neurons = length of one pattern
n = patterns.shape[1]

# Initialize weight matrix (n x n) with zeros
weights = np.zeros((n, n))

# Calculate weights: W = sum of X^T * X over all patterns
for pattern in patterns:
    weights += np.outer(pattern, pattern)

# Remove self-connections (diagonal = 0)
np.fill_diagonal(weights, 0)

print("Weight Matrix:")
print(weights)

# Noisy input pattern (2nd value is wrong compared to [1, 1, -1, -1])
input_pattern = np.array([1, -1, -1, -1])

# Copy input pattern so the original is not changed
state = input_pattern.copy()

# Recall the stored pattern
for iteration in range(10):

    # Calculate new state: sign of the weighted sum (+1 or -1)
    new_state = np.sign(np.dot(weights, state))

    # Replace 0 with 1 (net = 0 counts as active)
    new_state[new_state == 0] = 1

    print("Iteration", iteration + 1, ":", new_state)

    # Check stable state: stop if nothing changed
    if np.array_equal(new_state, state):
        break

    state = new_state

print("\nRecalled Pattern:")
print(state)
