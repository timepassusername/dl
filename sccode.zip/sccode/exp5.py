r"""
Practical 5: Hebb's Learning Rule

AIM:
    To implement Hebb's Learning Rule for training a simple Artificial
    Neural Network.

THEORY (in simple words):
    - Proposed by Donald Hebb in 1949. Main idea:
          "Neurons that fire together, wire together."
      If an input and the output are active together, the connection
      (weight) between them becomes stronger.
    - Weight update formula:
          W(new) = W(old) + X * Y
          X = input, Y = target output
    - Hebb's rule does NOT calculate any error. It simply adds
      input x target for every training pattern.
    - Uses: pattern recognition, associative memory.

HOW THE CODE WORKS:
    - Inputs X and targets Y use bipolar values (+1 / -1).
    - Weights start at [0, 0].
    - For each of the 4 patterns we do  weights = weights + X[i] * Y[i]
      and print the weights after every update.
    - Step-by-step:
          start           -> [0, 0]
          [ 1,  1] *  1   -> [1, 1]
          [ 1, -1] * -1   -> [0, 2]
          [-1,  1] * -1   -> [1, 1]
          [-1, -1] *  1   -> [0, 0]
    - The final weights come out as [0, 0]. This is EXPECTED: these
      targets (output 1 when both inputs are the same) form an XNOR
      pattern, which a single neuron cannot learn because it is not
      linearly separable. The program still shows clearly how Hebb's
      rule updates weights step by step.

HOW TO RUN (Windows):
    1. Save this code as exp5.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp5.py

CONCLUSION:
    Hebb's Learning Rule was implemented successfully. The weights were
    updated using W(new) = W(old) + X * Y for every input pattern,
    showing the basic way a neural network learns from inputs and
    target outputs.
"""
import numpy as np

# Input patterns (bipolar: +1 / -1)
X = np.array([[1, 1],
              [1, -1],
              [-1, 1],
              [-1, -1]])

# Target outputs for each pattern
Y = np.array([1, -1, -1, 1])

# Initialize weights with zero
weights = np.zeros(2)

print("Initial Weights:", weights)

# Hebb Learning Rule: W(new) = W(old) + X * Y
for i in range(len(X)):
    weights = weights + X[i] * Y[i]
    print("Updated Weights after Pattern", i + 1, ":", weights)

print("\nFinal Weights:", weights)
