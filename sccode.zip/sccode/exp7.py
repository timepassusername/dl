r"""
Practical 7: Hebbian Learning for AND and OR Logic Gates

AIM:
    To implement the Hebbian Learning Algorithm for the AND and OR
    logic gates and check the learned weights and outputs.

THEORY (in simple words):
    - Hebbian learning: "When two neurons are active together, the
      connection between them becomes stronger."
    - Update formulas for every training pattern:
          W(new) = W(old) + X * Y
          b(new) = b(old) + Y          <- bias update
    - Bipolar values are used: +1 means ON, -1 means OFF.
    - The bias is needed for the AND gate. Without it, the neuron's
      line always passes through the centre (0, 0) and it cannot split
      [1, 1] from the other inputs.
    - Testing: net = X . W + b, output = +1 if net >= 0 else -1.

HOW THE CODE WORKS:
    Part A - AND gate (output +1 only for [1, 1]):
        - Start with weights [0, 0] and bias 0.
        - Add X * Y to the weights and Y to the bias for every pattern.
        - Final: weights = [2, 2], bias = -2.
          Check [1, -1]: 2 - 2 - 2 = -2 -> -1  (correct)
    Part B - OR gate (output -1 only for [-1, -1]):
        - Same steps with the OR targets.
        - Final: weights = [2, 2], bias = 2.
          Check [-1, -1]: -2 - 2 + 2 = -2 -> -1  (correct)
    - After training, each input is tested and the output printed.

HOW TO RUN (Windows):
    1. Save this code as exp7.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp7.py

CONCLUSION:
    The Hebbian Learning Algorithm was implemented successfully for the
    AND and OR gates. Using W(new) = W(old) + X * Y with a bias, the
    trained network classified every input pattern correctly.
"""
import numpy as np

# ---------- Part A: AND Gate ----------
# Bipolar inputs
X = np.array([
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1]
])
# AND targets: +1 only when both inputs are +1
Y = np.array([1, -1, -1, -1])
weights = np.array([0, 0])
bias = 0
# Training: Hebb rule for every pattern
for i in range(len(X)):
    weights = weights + X[i] * Y[i]
    bias = bias + Y[i]
print("Final Weights:", weights)
print("Final Bias:", bias)
print("\nTesting AND Gate:")
for i in range(len(X)):
    net = np.dot(X[i], weights) + bias     # weighted sum + bias

    # Bipolar step function: +1 or -1
    if net >= 0:
        output = 1
    else:
        output = -1
    print(X[i], "->", output)

# ---------- Part B: OR Gate ----------
X = np.array([
    [1, 1],
    [1, -1],
    [-1, 1],
    [-1, -1]
])
# OR targets: -1 only when both inputs are -1
Y = np.array([1, 1, 1, -1])
weights = np.array([0, 0])
bias = 0
# Training: Hebb rule for every pattern
for i in range(len(X)):
    weights = weights + X[i] * Y[i]
    bias = bias + Y[i]

print("\nFinal Weights:", weights)
print("Final Bias:", bias)
print("\nTesting OR Gate:")
for i in range(len(X)):
    net = np.dot(X[i], weights) + bias
    if net >= 0:
        output = 1
    else:
        output = -1
    print(X[i], "->", output)
