r"""
Practical 6: Backpropagation for Multilayer Perceptron (MLP)

AIM:
    To implement the Backpropagation algorithm for training a
    Multilayer Perceptron from scratch, and to use scikit-learn's
    MLPClassifier on real datasets (Iris and Adult Census Income).

THEORY (in simple words):
    - A Multilayer Perceptron has an input layer, one or more hidden
      layers and an output layer.
    - Backpropagation trains it in 4 stages, repeated many times:
          Forward Propagation -> Error -> Backward Propagation -> Weight Update
        * Forward propagation : input goes layer by layer to the output.
        * Error               : target output - predicted output.
        * Backpropagation     : the error is sent backwards to find how
                                much each weight caused the mistake.
        * Weight update       : weights change a little to reduce error.
    - Learning rate : how big each weight change is.
      Epoch         : one full pass over all training data.
    - Sigmoid function  : 1 / (1 + e^-x), squashes any number to 0..1.
      Its derivative is : s * (1 - s), used in backpropagation.
    - StandardScaler : puts all features on the same scale (mean 0,
                       std 1) so the network trains better.
      LabelEncoder   : turns text categories (e.g. Male/Female) into
                       numbers (0/1).

HOW THE CODE WORKS:
    Part 1 - XOR from scratch (only NumPy):
        - Random starting weights for input->hidden (2x2) and
          hidden->output (2x1).
        - 10000 epochs of: forward pass, find error, backpropagate,
          update weights.
        - Finally prints the rounded predictions [0, 1, 1, 0].

    Part 2 - Iris dataset (needs IRIS.csv in the same folder):
        - Load data with pandas, take 4 flower measurements as input
          and the species as output.
        - Split 80% train / 20% test, scale, train MLPClassifier with
          5 hidden neurons, predict and print the accuracy.

    Part 3 - Adult Census Income dataset (needs ADULT.csv):
        - Predict whether a person earns <=50K or >50K.
        - Clean data: replace '?' with missing, drop missing rows,
          strip spaces, convert text columns to numbers.
        - Split, scale, train MLPClassifier with 2 hidden layers
          (100 and 50 neurons, ReLU), predict and print the accuracy.
        - This part takes around a minute to train.

HOW TO RUN (Windows):
    1. Save this code as exp6.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy pandas scikit-learn
    6. Run the code      :  python exp6.py
    Note:
      - Put IRIS.csv and ADULT.csv in the same folder before running
      - Part 3 (Adult dataset) takes about 1-2 minutes, just wait

CONCLUSION:
    Backpropagation was implemented successfully from scratch on the
    XOR problem. MLP classifiers built with scikit-learn gave about
    100% accuracy on the Iris dataset and about 84% on the Adult Census
    Income dataset, showing that backpropagation-based networks work on
    both simple and real-world problems.
"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# =====================================================
# Implementation 1: Backpropagation from Scratch (XOR)
# =====================================================
print("===== Implementation 1: Backpropagation (XOR) =====")

# Input data: all combinations of two binary inputs
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
# Target output: XOR (1 when inputs are different)
y = np.array([[0], [1], [1], [0]])


# Sigmoid activation function: squashes values into 0..1
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


# Derivative of sigmoid (x is already a sigmoid output here)
def sigmoid_derivative(x):
    return x * (1 - x)


# Initialize weights randomly (seed makes results the same each run)
np.random.seed(1)
weights_input_hidden = np.random.rand(2, 2)    # 2 inputs -> 2 hidden neurons
weights_hidden_output = np.random.rand(2, 1)   # 2 hidden -> 1 output neuron
learning_rate = 0.5

# Training
for epoch in range(10000):
    # Forward Propagation: input -> hidden -> output
    hidden_input = np.dot(X, weights_input_hidden)
    hidden_output = sigmoid(hidden_input)
    final_input = np.dot(hidden_output, weights_hidden_output)
    predicted_output = sigmoid(final_input)
    # Calculate Error: how far we are from the target
    error = y - predicted_output
    # Backpropagation: find each layer's share of the error
    output_delta = error * sigmoid_derivative(predicted_output)
    hidden_error = np.dot(output_delta, weights_hidden_output.T)
    hidden_delta = hidden_error * sigmoid_derivative(hidden_output)
    # Update Weights: move a small step in the direction that lowers the error
    weights_hidden_output += learning_rate * np.dot(hidden_output.T, output_delta)
    weights_input_hidden += learning_rate * np.dot(X.T, hidden_delta)

print("Predicted Output:")
print(np.round(predicted_output))   # round 0.98 -> 1, 0.02 -> 0

# =====================================================
# Implementation 2: MLP Classifier - Iris Dataset
# =====================================================
print("\n===== Implementation 2: MLP Classifier (Iris) =====")

# Step 2: Load Kaggle Dataset
data = pd.read_csv("IRIS.csv")
print("Dataset:")
print(data.head())                  # first 5 rows
# Step 3: Check Dataset Information
print("\nDataset Shape:", data.shape)   # (rows, columns)
print("\nColumns:")
print(data.columns)
# Step 4: Separate Input and Output
X = data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
y = data['species']
# Step 5: Split Dataset (80% for training, 20% for testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# Step 6: Scale the Input Data (fit on train only, then apply to test)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
# Step 7: Create MLP Model (1 hidden layer with 5 neurons, sigmoid)
model = MLPClassifier(hidden_layer_sizes=(5,), activation='logistic', learning_rate_init=0.1,
                      max_iter=2000, random_state=42)
# Step 8: Train Model
# MLPClassifier trains the neural network using backpropagation
model.fit(X_train, y_train)
# Step 9: Prediction on unseen test data
y_pred = model.predict(X_test)
# Step 10: Display Predictions
print("\nActual Output:")
print(y_test.values)
print("\nPredicted Output:")
print(y_pred)
# Step 11: Accuracy = correct predictions / total predictions
accuracy = accuracy_score(y_test, y_pred)
print("\nAccuracy:", accuracy * 100, "%")

# =====================================================
# Implementation 3: MLP Classifier - Adult Census Income
# =====================================================
print("\n===== Implementation 3: MLP Classifier (Adult Census) =====")

# Load Adult Dataset (the file has no header row)
data = pd.read_csv(
    "ADULT.csv",
    header=None,
    skipinitialspace=True
)
# Column Names
data.columns = [
    'age', 'workclass', 'fnlwgt', 'education', 'education_num',
    'marital_status', 'occupation', 'relationship', 'race', 'sex',
    'capital_gain', 'capital_loss', 'hours_per_week',
    'native_country', 'income'
]
print("Dataset:")
print(data.head())
print("\nDataset Shape:", data.shape)
print("\nColumns:")
print(data.columns)
# Replace missing values ('?' in this dataset means unknown)
data.replace('?', pd.NA, inplace=True)
# Remove rows with missing values
data.dropna(inplace=True)
# Remove extra spaces from text columns
for col in data.select_dtypes(include=['object', 'string']).columns:
    data[col] = data[col].str.strip()
# Convert categorical (text) columns to numbers
le = LabelEncoder()
for col in data.select_dtypes(include=['object', 'string']).columns:
    data[col] = le.fit_transform(data[col])
# Separate Input and Output (income is what we predict)
X = data.drop('income', axis=1)
y = data['income']
# Split Dataset (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)
# Scale Input Data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
# Create Neural Network (2 hidden layers: 100 and 50 neurons, ReLU)
model = MLPClassifier(
    hidden_layer_sizes=(100, 50),
    activation='relu',
    learning_rate_init=0.0001,
    max_iter=5000,
    random_state=100
)
# Train Model
model.fit(X_train, y_train)
# Predict
y_pred = model.predict(X_test)
# Display Results (0 = <=50K, 1 = >50K)
print("\nActual Output:")
print(y_test.values)
print("\nPredicted Output:")
print(y_pred)
# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print("\nAccuracy: {:.2f}%".format(accuracy * 100))
