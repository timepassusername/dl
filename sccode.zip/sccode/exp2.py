r"""
Practical 2: Simple Linear Neural Network for Binary Classification

AIM:
    To design a simple Linear Neural Network that puts inputs into one
    of two classes (0 or 1).

THEORY (in simple words):
    - A neural network copies the idea of a brain neuron. The simplest
      one has inputs, weights, a bias and one output neuron.
    - Weight : how important an input is.
      Bias   : an extra number that shifts the result up or down.
    - The neuron works like this:
          net = (x1 * w1) + (x2 * w2) + bias
          output = 1 if net >= 0, else 0      <- Step Activation Function
    - "Binary classification" means the answer is only one of two
      classes: 0 or 1.

HOW THE CODE WORKS:
    - Inputs X are all 4 combinations of two bits.
    - Target y = [0, 0, 0, 1], so only [1, 1] should give 1 (like AND).
    - We fix weights = [1, 1] and bias = -1.5 (no training here).
          [1, 1] -> 1 + 1 - 1.5 =  0.5 -> output 1
          [0, 1] -> 0 + 1 - 1.5 = -0.5 -> output 0
    - For every input we calculate net, apply the step function and
      print the result.

HOW TO RUN (Windows):
    1. Save this code as exp2.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp2.py

CONCLUSION:
    The linear neural network was implemented successfully. Using
    weights, bias and the step activation function, it classified all
    inputs correctly into class 0 or class 1.
"""
import numpy as np

# Input Data: all combinations of two binary inputs
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

# Target Output: what we expect for each input
y = np.array([0, 0, 0, 1])

# Initialize Weights and Bias (chosen by hand)
weights = np.array([1, 1])
bias = -1.5


# Step Activation Function: gives 1 if net is 0 or more, else 0
def step_function(x):
    if x >= 0:
        return 1
    else:
        return 0


print("Predicted Output")

for i in range(len(X)):
    # Weighted sum: x1*w1 + x2*w2 + bias
    net = np.dot(X[i], weights) + bias
    # Turn the weighted sum into 0 or 1
    output = step_function(net)
    print(X[i], "->", output)
