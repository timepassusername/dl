r"""
Practical 4: XOR using Multilayer Perceptron (Backpropagation)

AIM:
    To solve the XOR problem using a Multilayer Perceptron (MLP)
    trained with the Backpropagation algorithm.

THEORY (in simple words):
    - XOR gives 1 when the two inputs are DIFFERENT:
          0,0 -> 0   0,1 -> 1   1,0 -> 1   1,1 -> 0
    - A single perceptron can only draw ONE straight line to separate
      classes. XOR's points cannot be split by one straight line, so a
      single perceptron fails.
    - A Multilayer Perceptron adds a HIDDEN LAYER between input and
      output. The hidden layer lets the network learn curved / complex
      boundaries, so it can solve XOR.
    - Backpropagation is how the MLP learns:
          1. Forward pass : calculate the output.
          2. Find the error (target - output).
          3. Backward pass: send the error back through the layers.
          4. Update weights and biases to reduce the error.
          5. Repeat many times (epochs).

HOW THE CODE WORKS:
    - We use scikit-learn's ready-made MLPClassifier, which does
      backpropagation for us inside .fit().
    - hidden_layer_sizes=(4,) -> one hidden layer with 4 neurons.
    - activation='logistic'   -> sigmoid function (output 0 to 1).
    - solver='lbfgs'          -> the method used to update weights;
                                 works well on tiny datasets.
    - random_state=1          -> same starting weights every run.
    - After training, predict() gives the output for each input.

HOW TO RUN (Windows):
    1. Save this code as exp4.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy scikit-learn
    6. Run the code      :  python exp4.py

CONCLUSION:
    The XOR function was implemented successfully using a Multilayer
    Perceptron. Backpropagation adjusted the weights until the network
    gave the correct XOR output for all four inputs.
"""
from sklearn.neural_network import MLPClassifier
import numpy as np

# XOR Input: all combinations of two binary inputs
X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

# XOR Output: 1 only when the inputs are different
y = np.array([0, 1, 1, 0])

# Create MLP Model (1 hidden layer with 4 neurons, sigmoid activation)
model = MLPClassifier(hidden_layer_sizes=(4,),
                      activation='logistic',
                      solver='lbfgs', max_iter=1000,
                      random_state=1)

# Train Model: backpropagation runs inside fit()
model.fit(X, y)

# Prediction: ask the trained network for the output of each input
prediction = model.predict(X)

print("Input Output")
for i in range(len(X)):
    print(X[i], " --> ", prediction[i])
