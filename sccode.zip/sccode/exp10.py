r"""
Practical 10: Simple Genetic Algorithm (maximize f(x) = x^2)

AIM:
    To implement a simple Genetic Algorithm (GA) that solves an
    optimization problem: find x (0 to 31) that gives the maximum
    value of f(x) = x^2.

THEORY (in simple words):
    - A Genetic Algorithm copies natural evolution: "survival of the
      fittest". Good solutions survive and mix to make better ones.
    - Key terms:
        Chromosome : one possible solution, written in binary
                     (e.g. 10110 = 22).
        Population : a group of chromosomes.
        Fitness    : how good a solution is (here f(x) = x^2).
    - Steps, repeated for many generations:
        1. Initialization : make a random population.
        2. Fitness        : score every chromosome.
        3. Selection      : pick the best ones as parents.
        4. Crossover      : mix two parents to make children
                            (first part from one, rest from the other).
        5. Mutation       : randomly flip a few bits (0 <-> 1) to keep
                            variety.
        6. Replacement    : form the new population.
    - At the end, the chromosome with the highest fitness is the answer.

HOW THE CODE WORKS:
    - 6 chromosomes, each 5 bits long (so x is 0 to 31), 20 generations,
      mutation rate 10%.
    - decode() turns binary into decimal, e.g. [1,0,1,1,0] -> 22.
    - fitness() returns x^2.
    - Every generation: pick the 2 best as parents, cross them at a
      random point to get 2 children, mutate the children, then build
      a new population (2 parents + 2 children + 2 random old ones).
    - Finally print the best chromosome, its x value and its fitness.
      The best possible answer is 11111 -> x = 31 -> fitness = 961.
    - No random seed is set, so each run can be a little different.

HOW TO RUN (Windows):
    1. Save this code as exp10.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp10.py
    Note:
      - Answer can change a little on each run (random)

CONCLUSION:
    The simple Genetic Algorithm was implemented successfully. Through
    selection, crossover and mutation, the population evolved over the
    generations and found the solution that maximizes f(x) = x^2.
"""
import numpy as np

# Parameters
population_size = 6       # number of chromosomes
chromosome_length = 5     # bits per chromosome (x from 0 to 31)
generations = 20          # how many times we evolve
mutation_rate = 0.1       # 10% chance to flip each bit

# Initial population: random 0s and 1s
population = np.random.randint(
    0, 2, (population_size, chromosome_length)
)


# Convert binary chromosome to decimal, e.g. [1, 0, 1] -> 5
def decode(chromosome):
    value = 0

    for bit in chromosome:
        value = value * 2 + bit

    return value


# Fitness function: bigger x^2 = better solution
def fitness(chromosome):
    x = decode(chromosome)
    return x ** 2


# Genetic Algorithm
for generation in range(generations):

    # Score every chromosome
    fitness_values = np.array(
        [fitness(chromosome) for chromosome in population]
    )

    # Selection: choose the two best chromosomes
    best_indices = np.argsort(fitness_values)[-2:]

    parent1 = population[best_indices[0]]
    parent2 = population[best_indices[1]]

    # Crossover: cut both parents at a random point and swap the tails
    crossover_point = np.random.randint(1, chromosome_length)

    child1 = np.concatenate((
        parent1[:crossover_point],
        parent2[crossover_point:]
    ))

    child2 = np.concatenate((
        parent2[:crossover_point],
        parent1[crossover_point:]
    ))

    # Mutation: flip some bits at random (0 -> 1 or 1 -> 0)
    for child in [child1, child2]:

        for i in range(chromosome_length):

            if np.random.rand() < mutation_rate:
                child[i] = 1 - child[i]

    # Create new population: parents + children + 2 random old members
    population = np.array([
        parent1,
        parent2,
        child1,
        child2,
        population[np.random.randint(population_size)],
        population[np.random.randint(population_size)]
    ])

# Find best solution in the final population
fitness_values = np.array(
    [fitness(chromosome) for chromosome in population]
)

best_index = np.argmax(fitness_values)

best_chromosome = population[best_index]
best_x = decode(best_chromosome)
best_fitness = fitness(best_chromosome)

print("Best Chromosome:", best_chromosome)
print("Best Value of x:", best_x)
print("Maximum Fitness:", best_fitness)
