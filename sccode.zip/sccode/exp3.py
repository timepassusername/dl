r"""
Practical 3: Perceptron for AND and OR Logic Gates

AIM:
    To implement a Perceptron that works as an AND gate and an OR gate.

THEORY (in simple words):
    - A Perceptron (by Frank Rosenblatt, 1958) is the simplest neural
      network: a single neuron with weights, a bias and a step function.
    - It calculates  net = x1*w1 + x2*w2 + bias  and outputs 1 if
      net >= 0, otherwise 0.
    - By choosing the right weights and bias, the same neuron can act
      like different logic gates:
          AND : output 1 only when BOTH inputs are 1
          OR  : output 1 when AT LEAST ONE input is 1
    - The bias acts like a "threshold" (how hard it is to fire):
          AND -> bias = -1.5 (needs both inputs to cross 0)
          OR  -> bias = -0.5 (one input is enough to cross 0)

HOW THE CODE WORKS:
    - X holds the 4 input combinations.
    - weights = [1, 1] for both gates; only the bias changes.
    - For each input we find net, apply step(), and print the output,
      first for AND and then for OR.

HOW TO RUN (Windows):
    1. Save this code as exp3.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy
    6. Run the code      :  python exp3.py

CONCLUSION:
    The perceptron was implemented successfully for the AND and OR
    gates. With proper weights and bias it classified every input
    combination correctly, showing how a single neuron makes decisions.
"""
import numpy as np

# Input Data: all combinations of two binary inputs
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])


# Step Activation Function: 1 if net >= 0, else 0
def step(x):
    if x >= 0:
        return 1
    else:
        return 0


# ---------- AND Gate ----------
print("AND Gate")
weights = np.array([1, 1])
bias = -1.5          # high threshold: both inputs must be 1

for i in range(len(X)):
    net = np.dot(X[i], weights) + bias     # weighted sum
    output = step(net)                     # 0 or 1
    print(f"{X[i]} -> {output}")

# ---------- OR Gate ----------
print("\nOR Gate")
bias = -0.5          # low threshold: one input being 1 is enough

for i in range(len(X)):
    net = np.dot(X[i], weights) + bias
    output = step(net)
    print(f"{X[i]} -> {output}")
