r"""
Practical 8: Kohonen Self-Organizing Map (SOM)

AIM:
    To implement a Kohonen Self-Organizing Map for unsupervised learning
    and clustering (grouping) of input data.

THEORY (in simple words):
    - A SOM was introduced by Teuvo Kohonen. It is UNSUPERVISED: we give
      only the data, no correct answers (labels). It finds groups of
      similar data by itself.
    - It has a grid of neurons. Each neuron has a weight vector, which
      is like a "position" in the data space.
    - For each input:
        1. Find the distance from the input to every neuron
           (Euclidean distance).
        2. The closest neuron is the Best Matching Unit (BMU), the
           "winner".
        3. Move the BMU's weights closer to the input:
               W(new) = W(old) + learning_rate * (X - W(old))
    - Repeat many times. Neurons end up sitting in the middle of the
      groups, so similar inputs get the same neuron.
    - The learning rate is slowly reduced so later changes are small
      and the map settles down.

HOW THE CODE WORKS:
    - data has 6 points forming 2 clear groups:
          near (1, 1) and near (8, 8).
    - The SOM is a 2 x 2 grid (4 neurons) with random starting weights.
    - 100 epochs: for each point find the BMU and pull it toward the
      point; after each epoch learning_rate *= 0.99.
    - At the end we print the final weights and which neuron each
      point belongs to. Points from the same group share a neuron.

HOW TO RUN (Windows):
    1. Save this code as exp8.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install numpy matplotlib
    6. Run the code      :  python exp8.py

CONCLUSION:
    The Kohonen Self-Organizing Map was implemented successfully. By
    finding the Best Matching Unit and updating its weights, the SOM
    grouped similar input points together without any labels, showing
    unsupervised learning and clustering.
"""
import numpy as np
import matplotlib.pyplot as plt

# Input data: 2 groups of points (around (1,1) and around (8,8))
data = np.array([
    [1, 1],
    [1, 2],
    [2, 1],
    [8, 8],
    [8, 9],
    [9, 8]
])

# SOM size: 2 x 2 grid = 4 neurons
rows = 2
cols = 2

# Initialize weights randomly: every neuron gets a random (x, y) position
np.random.seed(1)
weights = np.random.rand(rows, cols, 2)

# Learning rate: how far the winner moves toward the input
learning_rate = 0.5

# Training
for epoch in range(100):
    for x in data:

        # Find Best Matching Unit (BMU): distance from x to every neuron
        distances = np.linalg.norm(weights - x, axis=2)

        # Position (row, col) of the neuron with the smallest distance
        bmu = np.unravel_index(
            np.argmin(distances),
            distances.shape
        )

        # Update BMU weights: move the winner closer to the input
        weights[bmu] = weights[bmu] + \
            learning_rate * (x - weights[bmu])

    # Reduce learning rate a little after every epoch
    learning_rate *= 0.99

# Display final weights
print("Final SOM Weights:")
print(weights)

# Display cluster assignment: which neuron wins for each point
print("\nCluster Assignment:")

for x in data:
    distances = np.linalg.norm(weights - x, axis=2)

    bmu = np.unravel_index(
        np.argmin(distances),
        distances.shape
    )

    print(x, "-> Neuron", bmu)
