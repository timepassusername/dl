"""
EXPERIMENT 5 - NEURAL NETWORK (TensorFlow / Keras)

AIM:
    Implement a neural network algorithm for cognitive computing.

THEORY:
    - An Artificial Neural Network (ANN) is a model inspired by the brain,
      made of connected units called neurons.
    - Layers:  Input layer  -> receives data
               Hidden layer -> processes data (weights + activation)
               Output layer -> gives the final result
    - Working: input -> weighted calculation -> prediction -> error
               calculated -> weights updated -> repeat until learned.
    - Optimizer     = adjusts weights/biases to reduce loss (here: SGD)
    - Loss function = difference between predicted and actual value
                      (here: mean squared error)

    Here the network learns the rule  Y = 2 * X  from 5 examples.
"""

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 1. Training data (pattern: Y is double of X)
X = np.array([1, 2, 3, 4, 5], dtype=float)
Y = np.array([2, 4, 6, 8, 10], dtype=float)

# 2. Build network: ONE neuron, takes ONE input
model = Sequential()
model.add(Dense(units=1, input_shape=[1]))

# 3. Compile: choose optimizer and loss
model.compile(optimizer="sgd", loss="mean_squared_error")

# 4. Train for 500 rounds (epochs); verbose=0 hides the progress
model.fit(X, Y, epochs=500, verbose=0)

# 5. Predict for a new value (answer should be close to 12)
prediction = model.predict(np.array([6.0]))
print("Prediction for 6 =", prediction[0][0])

# EXPECTED OUTPUT: Prediction for 6 = ~11.9  (close to 12, not exact)
# CONCLUSION: The network learned the pattern from data and predicted
# a new value.
