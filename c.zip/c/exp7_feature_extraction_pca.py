"""
EXPERIMENT 7 - FEATURE EXTRACTION (PCA)

AIM:
    Implement feature extraction.

THEORY:
    - Feature extraction = turning raw data into a smaller set of
      meaningful features for machine learning.
    - Why: reduces dimensions, removes irrelevant info, speeds up
      training, improves accuracy.
    - PCA (Principal Component Analysis) = a dimensionality reduction
      technique. It converts many correlated features into fewer new
      features called PRINCIPAL COMPONENTS, keeping most information.
    - Other techniques: TF-IDF / Bag of Words (text), edges/shapes (images).
    - Standardise first (StandardScaler) so all features have equal scale.
"""

from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 1. Load data (4 features per flower).
# NOTE: Lab manual uses the Kaggle file. If you have Iris.csv, use instead:
#   import pandas as pd
#   X = pd.read_csv("Iris.csv").iloc[:, 1:5]
X = load_iris().data

# 2. Standardise the data (mean 0, spread 1)
X_scaled = StandardScaler().fit_transform(X)

# 3. PCA: reduce 4 features to 2 principal components
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# 4. Show result
print("Original Shape:", X.shape)       # (150, 4)
print("Reduced Shape:", X_pca.shape)    # (150, 2)
print("\nExtracted Features:")
print(X_pca[:5])                        # first 5 rows

# EXPECTED OUTPUT: Original (150, 4), Reduced (150, 2),
#                  first row about [-2.26  0.48] (Kaggle Iris.csv gives [-2.26  0.51])
# CONCLUSION: PCA reduced 4 features to 2 while keeping most information.
