"""
EXPERIMENT 6 - PATTERN RECOGNITION (KNN on Iris dataset)

AIM:
    Implement pattern recognition.

THEORY:
    - Pattern Recognition = identifying regularities/patterns in data so a
      computer can classify things (faces, speech, handwriting, etc.)
    - Process: Data collection -> Feature extraction -> Train model
               -> Classification -> Prediction
    - KNN (K-Nearest Neighbours): a new point is given the class that
      most of its K nearest neighbours have.
    - Feature = a measurable property (e.g. petal length).
    - Accuracy = correct predictions / total predictions.
"""

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# 1. Load the Iris flower dataset
iris = load_iris()
X = iris.data      # features (sepal/petal sizes)
y = iris.target    # labels (flower type 0, 1, 2)

# 2. Split: 80% for training, 20% for testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# 3. Create KNN model using 3 neighbours
model = KNeighborsClassifier(n_neighbors=3)

# 4. Train the model
model.fit(X_train, y_train)

# 5. Predict on test data and check accuracy
predictions = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, predictions))

# 6. Predict a brand-new flower [sepal len, sepal wid, petal len, petal wid]
print("Predicted Class:", model.predict([[5.1, 3.5, 1.4, 0.2]]))

# EXPECTED OUTPUT: Accuracy: 1.0
#                  Predicted Class: [0]   (0 = Setosa)
# CONCLUSION: KNN learned patterns from Iris data and classified new samples.
