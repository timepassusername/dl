"""
EXPERIMENT 4 - DATA MINING (K-MEANS CLUSTERING)

AIM:
    Implement a data mining algorithm for cognitive computing.

THEORY:
    - Data Mining = extracting useful patterns/relationships from large data.
    - K-Means is an UNSUPERVISED algorithm (no labels given).
    - It groups similar points into K clusters.
    - Each cluster is represented by a CENTROID (mean of its points).

    K-Means steps (remember: S-I-A-R-R):
      1. Select K (number of clusters)
      2. Initialise centroids
      3. Assign each point to nearest centroid
      4. Recalculate centroids
      5. Repeat until clusters stop changing

    Uses: customer segmentation, fraud detection, recommendation systems.
"""

from sklearn.cluster import KMeans      # the K-Means algorithm
import matplotlib.pyplot as plt         # for the graph

# 1. Sample data: 6 points, each is [x, y]
X = [[1, 2], [1.5, 1.8], [5, 8], [8, 8], [1, 0.6], [9, 11]]

# 2. Create model: 2 clusters. random_state=0 -> same result every run
kmeans = KMeans(n_clusters=2, random_state=0)

# 3. Train model (finds the clusters)
kmeans.fit(X)

# 4. Results
print("Clusters:", kmeans.labels_)           # cluster number of each point
print("Centroids:\n", kmeans.cluster_centers_)  # centre of each cluster

# 5. Plot: points coloured by cluster, centroids as red X
plt.scatter([p[0] for p in X], [p[1] for p in X], c=kmeans.labels_)
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1],
            c="red", marker="x", s=100)
plt.title("K-Means Clustering (K=2)")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.show()

# EXPECTED OUTPUT: Clusters: [1 1 0 0 1 0]  (the 0/1 numbering may swap)
# CONCLUSION: K-Means grouped similar points together, showing how data
# mining discovers patterns in data.
