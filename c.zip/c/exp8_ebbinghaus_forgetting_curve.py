"""
PRACTICAL 8 - EBBINGHAUS FORGETTING CURVE

AIM:
    Implement and visualise the forgetting curve, with and without revision.

THEORY:
    - Hermann Ebbinghaus studied memory: we forget fast at first, then
      more slowly. (A simple model, not an exact prediction for anyone.)
    - Model (exponential decay):   R(t) = R0 * e^(-k*t)
        R0 = initial retention (100%)
        k  = forgetting-rate constant (bigger k = faster forgetting)
        t  = time in days
    - Revision (simplified): on a revision day, 70% of the forgotten
      amount is recovered. The 70% is an assumption, not a real value.
"""

import numpy as np
import matplotlib.pyplot as plt

# 1. Settings
R0 = 100                  # starting memory (%)
k = 0.5                   # forgetting rate
recovery = 0.70           # fraction of forgotten part recovered on revision
revision_days = [2, 5, 8]

# 2. Time axis: 0 to 10 days in steps of 0.05
days = np.linspace(0, 10, 201)

# 3. Without revision: use the formula directly
without = R0 * np.exp(-k * days)

# 4. With revision: decay step by step, boost on revision days
with_rev = []
r = R0
step = 0.05
for d in days:
    if d > 0:
        r = r * np.exp(-k * step)          # forget a little
    if any(np.isclose(d, rd) for rd in revision_days):
        r = r + recovery * (R0 - r)        # recover 70% of what was forgotten
    with_rev.append(r)

# 5. Print a small table
print("Day   Without    With")
for d in [0, 1, 2, 3, 5, 7, 8, 10]:
    i = np.argmin(np.abs(days - d))
    print(f"{d:<5} {without[i]:<10.2f} {with_rev[i]:.2f}")

# 6. Plot both curves
plt.plot(days, without, label="Without Revision")
plt.plot(days, with_rev, label="With Revision (70% recovery)")
for rd in revision_days:
    plt.axvline(rd, linestyle="--", alpha=0.5)   # mark revision days
plt.title("Ebbinghaus Forgetting Curve")
plt.xlabel("Time (Days)")
plt.ylabel("Memory Retention (%)")
plt.legend()
plt.grid(True)
plt.show()

# EXPECTED OUTPUT (table): day 1 -> 60.65, day 2 -> 36.79 / 81.04,
#                          day 10 -> 0.67 / 27.61
# CONCLUSION: Memory decays over time; revision lifts retention, but it
# decays again afterwards.
