"""
PRACTICAL 9 - ARTIFICIAL NEURON (OR GATE) USING TensorFlow/Keras

AIM:
    Implement a simplified neuroscientific model of an artificial neuron
    showing how inputs, weights, bias and activation give an output.

THEORY:
    - Biological neuron: dendrites receive signals -> cell body (soma)
      combines them -> axon sends the output signal.
    - Artificial neuron:
          z = w1*x1 + w2*x2 + b        (weighted sum + bias)
          y = sigmoid(z) = 1 / (1 + e^-z)   (output between 0 and 1)
        weights = importance of each input
        bias    = shifts the decision boundary
        activation function = adds non-linearity
    - If output >= 0.5 -> class 1, else class 0.
    - OR gate: output is 1 if at least one input is 1.
      It is linearly separable, so one neuron can learn it.
"""

import numpy as np
import tensorflow as tf

tf.random.set_seed(42)   # same result every run

# 1. Inputs and expected OR outputs
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=float)
Y = np.array([0, 1, 1, 1], dtype=float)

# 2. One neuron: 2 inputs, sigmoid activation
model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(2,)),
    tf.keras.layers.Dense(1, activation="sigmoid")
])

# 3. Compile: SGD optimizer, binary loss (for 0/1 answers)
model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=0.5),
              loss="binary_crossentropy", metrics=["accuracy"])

# 4. Train
model.fit(X, Y, epochs=500, verbose=0)

# 5. Predict and convert to 0/1 using the 0.5 rule
prediction = model.predict(X, verbose=0)
predicted = (prediction >= 0.5).astype(int).flatten()

print("Neuron Output  :", prediction.flatten())
print("Expected Output:", Y.astype(int))
print("Predicted Output:", predicted)

# EXPECTED OUTPUT: Expected [0 1 1 1], Predicted [0 1 1 1]
# CONCLUSION: A single neuron with sigmoid learned the OR function.
