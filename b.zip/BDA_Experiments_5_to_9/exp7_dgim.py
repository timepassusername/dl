"""
THEORY:
DGIM stands for Datar-Gionis-Indyk-Motwani. It is an algorithm used to
estimate the number of 1s in the most recent part of a binary data stream.
Instead of storing every bit, it stores groups of 1s in buckets. Bucket
sizes are powers of two, and old buckets of the same size are merged to
save memory. A sliding window removes data that is too old. The answer
is an estimate rather than an exact count.
"""

class DGIM:
    def __init__(self, window_size):
        self.window_size = window_size
        self.buckets = []  # Each bucket is [size, ending_timestamp].
        self.time = 0

    def add(self, bit):
        # Move the stream clock forward for every incoming bit.
        self.time += 1

        # Remove buckets that have completely expired from the window.
        self.buckets = [
            bucket for bucket in self.buckets
            if self.time - bucket[1] < self.window_size
        ]

        # A bucket is created only when the incoming bit is 1.
        if bit == 1:
            self.buckets.append([1, self.time])

        # Keep newest buckets first.
        self.buckets.sort(key=lambda bucket: bucket[1], reverse=True)

        # DGIM allows at most two buckets of each size.
        # If there are three, merge the two oldest buckets of that size.
        while True:
            merged = False
            sizes = sorted(set(bucket[0] for bucket in self.buckets))

            for size in sizes:
                same_size = [
                    i for i, bucket in enumerate(self.buckets)
                    if bucket[0] == size
                ]

                if len(same_size) > 2:
                    # The last two matching indices are the oldest buckets
                    # because buckets are ordered newest to oldest.
                    newer_old = same_size[-2]
                    oldest = same_size[-1]

                    # The merged bucket has double the size and keeps
                    # the ending timestamp of the newer of the two.
                    merged_bucket = [
                        size * 2,
                        self.buckets[newer_old][1]
                    ]

                    # Remove the two old buckets and add the merged one.
                    self.buckets.pop(oldest)
                    self.buckets.pop(newer_old)
                    self.buckets.append(merged_bucket)
                    self.buckets.sort(
                        key=lambda bucket: bucket[1], reverse=True
                    )
                    merged = True
                    break

            if not merged:
                break

    def estimate(self):
        # No buckets means there are no 1s in the current window.
        if not self.buckets:
            return 0

        # Add all bucket sizes.
        total = sum(bucket[0] for bucket in self.buckets)

        # Count only half of the oldest bucket because it may be
        # only partly inside the requested window.
        return total - self.buckets[-1][0] // 2


# MAIN PROGRAM
stream = [1, 0, 1, 1, 0, 1, 0, 1]
window_size = 8

dgim = DGIM(window_size)

# Send each bit to DGIM one by one.
for bit in stream:
    dgim.add(bit)

print("Data Stream:", stream)
print("Window Size:", window_size)
print("Estimated number of 1s:", dgim.estimate())
