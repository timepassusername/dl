"""
THEORY:
The Flajolet-Martin algorithm estimates the number of distinct (unique)
items in a data stream without storing every item. It applies a hash
function to each item and looks at the binary form of the hash value.
It finds the position of the rightmost 1 bit (equivalent to counting
trailing zeroes) and remembers the maximum position. The estimate is
calculated as 2 raised to that maximum position. The result is approximate.
"""

def rightmost_one_position(binary):
    # Reverse the binary string so the rightmost bit is checked first.
    binary = binary[::-1]

    # Return the zero-based position of the first 1 found.
    for position, bit in enumerate(binary):
        if bit == "1":
            return position

    return 0


def flajolet_martin(stream):
    max_position = 0

    # Process every item in the stream.
    for item in stream:
        # Convert the item into a 32-bit non-negative hash value.
        hash_value = hash(item) & 0xffffffff

        # Convert the hash value into a binary string (without '0b').
        binary = bin(hash_value)[2:]

        # Find the position of the rightmost 1 bit.
        position = rightmost_one_position(binary)

        # Keep the maximum position seen so far.
        if position > max_position:
            max_position = position

    # Estimate the number of distinct elements as 2 raised to max position.
    return 2 ** max_position


# MAIN PROGRAM
stream = ["A", "B", "C", "A", "B", "D", "C", "E"]

print("Data Stream:", stream)
estimate = flajolet_martin(stream)
print("Estimated Number of Distinct Elements:", estimate)

# Note: Python's built-in hash() can vary between program runs.
# Therefore, the approximate estimate may change on different runs.
