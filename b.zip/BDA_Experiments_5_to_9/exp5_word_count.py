"""
THEORY:
Word Count is used to find how many times each word appears in a text.
The text is first split into individual words. Each word is treated as a key
and the number 1 is assigned to it. Then the counts of matching words are
added together. In Hadoop MapReduce, the Mapper emits (word, 1), and the
Reducer adds the values for each word. This Python version demonstrates
the same counting idea on one computer.
"""

# Sample input text (like the input.txt file in the practical).
text = "Hadoop is big data Hadoop is useful"

# MAPPER IDEA:
# Split the input line into individual words.
words = text.split()

# Each word is treated as a key, and 1 is its count.
# REDUCER IDEA:
# Add 1 whenever the same word appears again.
word_count = {}

for word in words:
    if word in word_count:
        word_count[word] += 1
    else:
        word_count[word] = 1

# Display each word and its total count.
print("Input Text:", text)
print("\nWord Count:")
for word, count in word_count.items():
    print(word, count)
