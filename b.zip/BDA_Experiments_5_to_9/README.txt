BDA PRACTICALS - EXPERIMENTS 5 TO 9
Each Python file includes its aim, an easy one-paragraph theory explanation, and comments explaining the code.
===================================

Included files:
  exp5_word_count.py
  exp6_matrix_multiplication.py
  exp7_dgim.py
  exp8_bloom_filter.py
  exp9_flajolet_martin.py

HOW TO RUN ON WINDOWS
---------------------
1. Extract this ZIP folder.
2. Open the folder in VS Code.
3. Open Terminal > New Terminal.
4. Run one experiment at a time:

   python exp5_word_count.py
   python exp6_matrix_multiplication.py
   python exp7_dgim.py
   python exp8_bloom_filter.py
   python exp9_flajolet_martin.py

You can also run a file using the Run button in VS Code if Python is installed.

IMPORTANT NOTES
---------------
- Experiments 5 and 6 in the college practicals are specified as Hadoop
  MapReduce Java programs. These Python files demonstrate the same core
  calculations locally; they are not actual Hadoop MapReduce executions.
- Experiment 7's PDF provides the DGIM theory/procedure but its program
  page is blank. The included code is a simplified educational bucket
  implementation.
- Experiment 8 corrects the PDF's constructor typo: def init becomes
  def __init__ so the Python class works.
- Experiment 9 follows the PDF's hash-based approach. Python's built-in
  hash() is randomized between runs, so the estimate may vary.
