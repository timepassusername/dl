"""
EXPERIMENT 6: MATRIX MULTIPLICATION
Aim: Implementation of Matrix Multiplication Algorithm using MapReduce.

Python learning version:
This program multiplies two matrices locally using Python.
It demonstrates the matrix calculation that a MapReduce implementation
would distribute across Mapper and Reducer tasks. It is NOT a Hadoop job.
"""

# Input Matrix A.
A = [
    [1, 2],
    [3, 4]
]

# Input Matrix B.
B = [
    [5, 6],
    [7, 8]
]

# Number of rows and columns in the matrices.
rows_A = len(A)
cols_A = len(A[0])
cols_B = len(B[0])

# The number of columns in A must equal the number of rows in B.
if cols_A != len(B):
    raise ValueError("Matrix dimensions are not compatible for multiplication.")

# Create a result matrix filled with zeroes.
result = [[0 for j in range(cols_B)] for i in range(rows_A)]

# Multiply rows of A by columns of B.
for i in range(rows_A):
    for j in range(cols_B):
        for k in range(cols_A):
            # Multiply matching values and add the partial product.
            result[i][j] += A[i][k] * B[k][j]

# Display the resulting matrix.
print("Result Matrix:")
for row in result:
    print(row)
