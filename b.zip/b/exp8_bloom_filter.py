"""
EXPERIMENT 8: BLOOM FILTER
Aim: To implement the Bloom Filter algorithm using Python for efficient
membership testing of elements in a large dataset.

A Bloom Filter uses a bit array and multiple hash functions.
It answers either "Possibly Present" or "Definitely Not Present".
"""

class BloomFilter:
    def __init__(self, size):
        # Create a bit array filled with zeroes.
        self.size = size
        self.bit_array = [0] * size

    def hash1(self, item):
        # First hash function: add character codes and find array position.
        return sum(ord(char) for char in item) % self.size

    def hash2(self, item):
        # Second hash function: use a different calculation.
        return sum(ord(char) * 3 for char in item) % self.size

    def add(self, item):
        # Find the two positions for this item.
        index1 = self.hash1(item)
        index2 = self.hash2(item)

        # Mark both positions as 1 to indicate insertion.
        self.bit_array[index1] = 1
        self.bit_array[index2] = 1

    def check(self, item):
        # Calculate the same positions used during insertion.
        index1 = self.hash1(item)
        index2 = self.hash2(item)

        # If both positions are 1, the item may be present.
        if (self.bit_array[index1] == 1 and
                self.bit_array[index2] == 1):
            return "Possibly Present"

        # If any position is 0, the item is definitely absent.
        return "Definitely Not Present"


# MAIN PROGRAM
bloom = BloomFilter(10)

# Insert three items into the Bloom Filter.
bloom.add("Apple")
bloom.add("Mango")
bloom.add("Banana")

# Display the bit array and test membership.
print("Bloom Filter:", bloom.bit_array)
print("Apple:", bloom.check("Apple"))
print("Mango:", bloom.check("Mango"))
print("Orange:", bloom.check("Orange"))
