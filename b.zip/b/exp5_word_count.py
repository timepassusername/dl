"""
EXPERIMENT 5: WORD COUNT
Aim: Implementation of Word Count Program using Hadoop MapReduce.

Python learning version:
This program performs the same word-count calculation locally in Python.
It demonstrates the Mapper idea (emit each word with 1) and Reducer idea
(add the counts for each word). It is NOT an actual Hadoop MapReduce job.
"""

# Sample input text (like the input.txt file in the practical).
text = "Hadoop is big data Hadoop is useful"

# MAPPER IDEA:
# Split the input line into individual words.
words = text.split()

# Each word is treated as a key, and 1 is its count.
# REDUCER IDEA:
# Add 1 whenever the same word appears again.
word_count = {}

for word in words:
    if word in word_count:
        word_count[word] += 1
    else:
        word_count[word] = 1

# Display each word and its total count.
print("Input Text:", text)
print("\nWord Count:")
for word, count in word_count.items():
    print(word, count)
