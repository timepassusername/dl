r"""
Experiment 9: Time Series Prediction using RNN (Airline Passengers)

AIM:
    To implement a simple Recurrent Neural Network (RNN) to predict
    future values of a time series using the built-in Airline
    Passengers dataset.

THEORY (in simple words):
    - A TIME SERIES is data recorded over time in order, e.g. monthly
      sales, daily temperature or monthly airline passengers.
    - To predict the future we must look at the past values IN ORDER.
      An RNN is good at this because it reads a sequence step by step
      and keeps a memory (hidden state) of the earlier steps.
    - SLIDING WINDOW: we turn the series into small examples:
          past 12 months  ->  next month
          [m1 ... m12]    ->  m13
          [m2 ... m13]    ->  m14   ... and so on.
    - Scaling (MinMaxScaler) squeezes values into 0 to 1. Neural
      networks train better on small numbers, and it helps with the
      vanishing gradient problem (gradients becoming too tiny to learn).
    - Airline Passengers dataset (from seaborn): number of passengers
      every month from 1949 to 1960 (144 months).

HOW THE CODE WORKS:
    1. Load the 'flights' dataset from seaborn (it downloads once, so
       internet is needed the first time) and take the passengers column.
    2. Scale values to 0-1 with MinMaxScaler.
    3. Build sliding windows of 12 months -> next month.
       Reshape X to (samples, 12 time steps, 1 feature) because RNN
       layers expect 3D input.
    4. Split 80% train / 20% test WITHOUT shuffling, because order
       matters in time series (we train on the past, test on the future).
    5. Build: SimpleRNN(32) -> Dense(1). Loss = MSE (it's a number, not
       a class). Train for 30 epochs.
    6. Predict the test months, convert back to real passenger numbers
       with inverse_transform, and plot "Actual vs Predicted" and the
       "Loss over Epochs" graph.

HOW TO RUN (Windows):
    1. Save this code as exp9.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow numpy seaborn scikit-learn matplotlib
    6. Run the code      :  python exp9.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (seaborn downloads the flights data)
      - A graph window opens; close it to end the program

CONCLUSION:
    A simple RNN was implemented successfully for time series
    prediction. Using the past 12 months of airline passenger data, it
    predicted the next month's passengers, and the predicted curve
    followed the general trend of the actual values.
"""
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, SimpleRNN, Dense

# 1. Load built-in dataset
flights = sns.load_dataset('flights')
passengers = flights['passengers'].values.reshape(-1, 1)

# 2. Scale data between 0 and 1
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(passengers)

# 3. Create sliding windows (past 12 months -> next month)
n_steps = 12
X, y = [], []
for i in range(len(scaled_data) - n_steps):
    X.append(scaled_data[i:i + n_steps, 0])   # 12 months
    y.append(scaled_data[i + n_steps, 0])     # the month after
X, y = np.array(X), np.array(y)
X = X.reshape(X.shape[0], n_steps, 1)         # (samples, time steps, features)

# 4. Train-test split (no shuffle: keep time order)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# 5. Build RNN model
model = Sequential([
    Input(shape=(n_steps, 1)),
    SimpleRNN(32, activation='tanh'),   # reads 12 months in order
    Dense(1)                            # predicts one number: next month
])
model.compile(optimizer='adam', loss='mse')

# 6. Train
history = model.fit(X_train, y_train, epochs=30, batch_size=8)

# 7. Predict and convert back to real passenger numbers
predicted = model.predict(X_test)
predicted = scaler.inverse_transform(predicted)
actual = scaler.inverse_transform(y_test.reshape(-1, 1))

# 8. Plot results
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(actual, label='Actual')
plt.plot(predicted, label='Predicted')
plt.title('Airline Passengers Prediction using RNN')
plt.xlabel('Time (Months)')
plt.ylabel('Passengers')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.title('Loss over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')

plt.tight_layout()
plt.show()
