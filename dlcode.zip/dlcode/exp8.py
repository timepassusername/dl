r"""
Experiment 8: Sentiment Analysis on IMDB Reviews using RNN

AIM:
    To perform Sentiment Analysis on IMDB movie reviews using a
    Recurrent Neural Network (RNN), and plot accuracy/loss graphs to see
    how the network performs.

THEORY (in simple words):
    - SENTIMENT ANALYSIS: finding if a text is positive or negative.
      Used for product reviews, social media and customer feedback.
    - Text is a SEQUENCE: the order of words matters
      ("not good" means something different from "good").
    - A normal ANN looks at all inputs at once and has no memory. An RNN
      reads the words ONE BY ONE and keeps a MEMORY (hidden state) of
      what it has read so far.

      RNN architecture (unrolled over time):

          word1     word2     word3            last word
            |         |         |                  |
          [RNN] --> [RNN] --> [RNN] --> ... --> [RNN] --> Dense --> output
                 h1        h2        h3               (memory passed on)

        At each step: new memory = tanh(W * word + U * old memory)

    - Layers used:
        Embedding : turns each word number into a small vector of 32
                    values, so similar words get similar vectors.
        SimpleRNN : reads the vectors in order and remembers context.
        Dense     : 1 neuron with sigmoid -> 0 (negative) to 1 (positive).
    - IMDB dataset: 50,000 movie reviews (25k train, 25k test), already
      converted to numbers (each word = an index).

HOW THE CODE WORKS:
    1. Load IMDB, keeping only the 10,000 most common words.
    2. pad_sequences makes every review exactly 200 words long (cuts
       long reviews, adds 0s to short ones), because the network needs
       inputs of the same length.
    3. Build: Embedding -> SimpleRNN(32) -> Dense(1, sigmoid).
    4. Compile with binary_crossentropy (2 classes) and train for 5
       epochs with 20% validation data.
    5. Print test accuracy, show 5 sample predictions, and plot the
       accuracy and loss graphs.

HOW TO RUN (Windows):
    1. Save this code as exp8.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow matplotlib
    6. Run the code      :  python exp8.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads IMDB, ~17 MB)
      - Takes about 1 minute
      - A graph window opens; close it to end the program

CONCLUSION:
    Sentiment analysis on IMDB reviews was done successfully using a
    Recurrent Neural Network. By reading the words in order and keeping
    a memory of earlier words, the RNN classified reviews as positive or
    negative with good accuracy (about 80-85%), and the graphs showed
    how accuracy rose and loss fell during training.
"""
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Embedding, SimpleRNN, Dense

# 1. Load IMDB dataset (only the top 10,000 words)
vocab_size = 10000
(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=vocab_size)

# 2. Make all reviews the same length (200 words)
max_len = 200
x_train = pad_sequences(x_train, maxlen=max_len)
x_test = pad_sequences(x_test, maxlen=max_len)

# 3. Build RNN model
model = Sequential([
    Input(shape=(max_len,)),
    Embedding(vocab_size, 32),          # word number -> vector of 32 values
    SimpleRNN(32, activation='tanh'),   # reads words in order, keeps memory
    Dense(1, activation='sigmoid')      # 0 = negative, 1 = positive
])
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 4. Train
history = model.fit(x_train, y_train, epochs=5, batch_size=128, validation_split=0.2)

# 5. Evaluate
loss, accuracy = model.evaluate(x_test, y_test)
print("Test Accuracy:", accuracy)
print("Test Loss:", loss)

# 6. Sample predictions on 5 test reviews
predictions = model.predict(x_test[:5], verbose=0)
for i in range(5):
    predicted = "Positive" if predictions[i][0] >= 0.5 else "Negative"
    actual = "Positive" if y_test[i] == 1 else "Negative"
    print("Review", i + 1, "-> Predicted:", predicted, "| Actual:", actual)

# 7. Plot accuracy and loss
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train')
plt.plot(history.history['val_accuracy'], label='Validation')
plt.title('Accuracy')
plt.xlabel('Epoch')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train')
plt.plot(history.history['val_loss'], label='Validation')
plt.title('Loss')
plt.xlabel('Epoch')
plt.legend()

plt.tight_layout()
plt.show()
