r"""
Experiment 4: Simple Autoencoder on the Boston Housing Dataset

AIM:
    To implement a simple Autoencoder using TensorFlow and Keras that
    compresses and reconstructs data from the Boston Housing dataset.

THEORY (in simple words):
    - An Autoencoder is an UNSUPERVISED neural network: it does not need
      labels. Its job is to copy its input to its output.
    - It has two parts:
        ENCODER : squeezes the input into a smaller form
                  (13 numbers -> 4 numbers). This is the "compressed"
                  or "bottleneck" representation.
        DECODER : rebuilds the original input from that small form
                  (4 numbers -> 13 numbers).
    - Because the middle is small, the network is forced to keep only
      the most important information. This is called dimensionality
      reduction.
    - RECONSTRUCTION LOSS: how different the output is from the input.
      Here we use MSE (Mean Squared Error). Lower = better rebuild.
    - Uses: data compression, noise removal, anomaly detection (things
      that cannot be rebuilt well are "unusual").
    - Boston Housing dataset: 506 houses, each with 13 features
      (crime rate, number of rooms, tax rate, etc.). The house price
      labels are not needed, because an autoencoder is unsupervised.

HOW THE CODE WORKS:
    1. Load the dataset and keep only the features (labels ignored "_").
    2. Standardize each feature: (value - mean) / std, so all features
       are on the same scale.
    3. Build the autoencoder with the Keras functional API:
         Input(13) -> Dense(8) -> Dense(4)   <- encoder
                   -> Dense(8) -> Dense(13)  <- decoder
       The last layer is 'linear' because standardized values can be
       negative.
    4. Train with fit(X_train, X_train): the input is ALSO the target,
       so the network learns to rebuild its own input.
    5. Reconstruct the test data, print one original sample next to its
       rebuilt version, and print the reconstruction loss.

HOW TO RUN (Windows):
    1. Save this code as exp4.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow
    6. Run the code      :  python exp4.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads Boston Housing, tiny)

CONCLUSION:
    A simple Autoencoder was implemented successfully. The encoder
    compressed the 13 house features into 4 values and the decoder
    rebuilt them with a low reconstruction error, showing how
    unsupervised learning can find a compact representation of data.
"""
import tensorflow as tf
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model

# 1. Load Boston Housing Dataset (we don't need the price labels)
(X_train, _), (X_test, _) = tf.keras.datasets.boston_housing.load_data()

# 2. Standardize data: mean 0 and std 1 for every feature
mean = X_train.mean(axis=0)
std = X_train.std(axis=0)
X_train = (X_train - mean) / std
X_test = (X_test - mean) / std

# 3. Build Autoencoder
input_layer = Input(shape=(13,))                        # 13 features

# Encoder: compress 13 -> 8 -> 4
encoder = Dense(8, activation='relu')(input_layer)
encoder = Dense(4, activation='relu')(encoder)          # compressed form

# Decoder: rebuild 4 -> 8 -> 13
decoder = Dense(8, activation='relu')(encoder)
output_layer = Dense(13, activation='linear')(decoder)

autoencoder = Model(inputs=input_layer, outputs=output_layer)

# 4. Compile Model (MSE = reconstruction loss)
autoencoder.compile(optimizer='adam', loss='mse')
autoencoder.summary()

# 5. Train Model: input and target are the SAME data
autoencoder.fit(X_train, X_train,
                epochs=20, batch_size=16,
                validation_data=(X_test, X_test))

# 6. Reconstruct Test Data
reconstructed = autoencoder.predict(X_test)

print("\nOriginal Features (First Sample)")
print(X_test[0])
print("\nReconstructed Features (First Sample)")
print(reconstructed[0])

# 7. Reconstruction Error on the test set
loss = autoencoder.evaluate(X_test, X_test, verbose=0)
print("\nReconstruction Loss:", loss)
