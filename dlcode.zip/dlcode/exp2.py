r"""
Experiment 2: Multi-Layer Perceptron (MLP) on Fashion MNIST

AIM:
    To implement a Multi-Layer Perceptron using TensorFlow and Keras for
    classifying Fashion MNIST images (clothes, shoes, bags etc.).

THEORY (in simple words):
    - A Multi-Layer Perceptron (MLP) is a neural network with an input
      layer, TWO OR MORE hidden layers and an output layer.
    - Data flows only forward (feed-forward): input -> hidden layers ->
      output.
    - More hidden layers = the network can learn more complex patterns.
      For example, the first layer may learn edges, the next learns
      shapes, and the last learns "this looks like a shoe".
    - Each neuron: weighted sum of inputs -> activation -> next layer.
    - Fashion MNIST: 70,000 grey 28 x 28 images in 10 classes:
      T-shirt, Trouser, Pullover, Dress, Coat, Sandal, Shirt, Sneaker,
      Bag, Ankle boot. It is harder than digit MNIST.

HOW THE CODE WORKS:
    1. Load Fashion MNIST and divide pixels by 255 (values 0 to 1).
    2. Build the MLP:
         Flatten     -> 28x28 image becomes 784 numbers
         Dense(256)  -> hidden layer 1 (ReLU)
         Dense(128)  -> hidden layer 2 (ReLU)
         Dense(64)   -> hidden layer 3 (ReLU)
         Dense(10)   -> output, one neuron per class (Softmax)
       The layers get smaller step by step, squeezing the image down
       into the most useful information.
    3. Compile with Adam + sparse_categorical_crossentropy.
    4. Train for 10 epochs and check accuracy on the test images.

HOW TO RUN (Windows):
    1. Save this code as exp2.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow
    6. Run the code      :  python exp2.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads Fashion MNIST, ~30 MB)
      - Takes about 40 seconds

CONCLUSION:
    A Multi-Layer Perceptron was implemented successfully using
    TensorFlow and Keras. Using multiple hidden layers, it learned the
    features of the different clothing types and classified the Fashion
    MNIST test images with good accuracy (about 88-89%).
"""
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Flatten, Dense

# 1. Load Fashion MNIST dataset
(X_train, y_train), (X_test, y_test) = tf.keras.datasets.fashion_mnist.load_data()

# 2. Normalize the data (0-255 -> 0-1)
X_train = X_train / 255.0
X_test = X_test / 255.0

# 3. Build the Multi-Layer Perceptron
model = Sequential([
    Input(shape=(28, 28)),
    Flatten(),                        # image -> 784 numbers
    Dense(256, activation='relu'),    # hidden layer 1
    Dense(128, activation='relu'),    # hidden layer 2
    Dense(64, activation='relu'),     # hidden layer 3
    Dense(10, activation='softmax')   # output: 10 clothing classes
])

# 4. Compile the model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# 5. Train the model
model.fit(X_train, y_train, epochs=10, batch_size=32)

# 6. Evaluate the model on the test images
loss, accuracy = model.evaluate(X_test, y_test)
print("Test Accuracy:", accuracy)
print("Test Loss:", loss)
