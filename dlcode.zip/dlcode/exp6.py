r"""
Experiment 6: Batch Normalization in a Neural Network

AIM:
    To implement Batch Normalization in a neural network model using
    TensorFlow/Keras and evaluate its performance on a classification
    dataset.

THEORY (in simple words):
    - While a network trains, the outputs of each layer keep changing
      their range (sometimes big numbers, sometimes small). The next
      layer has to keep adjusting to this. This problem is called
      INTERNAL COVARIATE SHIFT.
    - BATCH NORMALIZATION fixes it. For every mini-batch it:
        1. finds the mean and variance of the layer's outputs,
        2. normalizes them:  z = (x - mean) / sqrt(variance + e),
        3. scales and shifts: y = gamma * z + beta
           (gamma and beta are learned by the network).
    - Benefits:
        * faster and more stable training
        * allows higher learning rates
        * often better accuracy on new data
    - Breast Cancer dataset: 569 patients, 30 features,
      target 0 = malignant, 1 = benign.

HOW THE CODE WORKS:
    1. Load the dataset, split 80/20, scale with StandardScaler
       (this normalizes the INPUT once; Batch Normalization normalizes
       the HIDDEN layers again and again during training).
    2. Build the model, with a BatchNormalization() layer after each
       hidden Dense layer:
         Dense(64) -> BatchNorm -> Dense(32) -> BatchNorm -> Dense(1)
    3. Compile with Adam + binary_crossentropy (2 classes).
    4. Train for 20 epochs with a 20% validation split.
    5. Print the test accuracy and loss.

HOW TO RUN (Windows):
    1. Save this code as exp6.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow scikit-learn
    6. Run the code      :  python exp6.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)

CONCLUSION:
    Batch Normalization was implemented successfully in a neural
    network. The model trained quickly and stably, and achieved high
    accuracy (about 97%) on the Breast Cancer test data.
"""
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Dense, BatchNormalization
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. Load Dataset
data = load_breast_cancer()
X = data.data
y = data.target

# 2. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 3. Feature Scaling (normalize the input features once)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 4. Build Model with Batch Normalization after each hidden layer
model = Sequential([
    Input(shape=(30,)),
    Dense(64, activation='relu'),
    BatchNormalization(),            # normalize this layer's outputs
    Dense(32, activation='relu'),
    BatchNormalization(),
    Dense(1, activation='sigmoid')   # output: probability of benign
])

# 5. Compile Model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 6. Train Model
model.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2)

# 7. Evaluate Model
loss, accuracy = model.evaluate(X_test, y_test)
print("\nTest Accuracy :", accuracy)
print("Test Loss :", loss)
