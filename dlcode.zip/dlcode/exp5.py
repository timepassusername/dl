r"""
Experiment 5: L2 Regularization in a Neural Network

AIM:
    To implement L2 Regularization for a neural network model using
    TensorFlow and Keras.

THEORY (in simple words):
    - OVERFITTING: the model memorizes the training data instead of
      learning general patterns. It does great on training data but
      badly on new data (like a student who memorizes answers but
      can't solve a new question).
    - One sign of overfitting is very LARGE weights.
    - L2 REGULARIZATION (also called Weight Decay) adds a penalty for
      large weights to the loss:
            Loss = Original Loss + lambda * sum(W^2)
        lambda (here 0.001) = how strong the penalty is
        W = the weights
    - So the model tries to keep the error low AND the weights small.
      Small weights give a smoother, simpler model that works better on
      unseen data (better "generalization").
    - Breast Cancer dataset (built into scikit-learn): 569 patients,
      30 measurements each. Target: 0 = malignant, 1 = benign.

HOW THE CODE WORKS:
    1. Load the dataset, split 80% train / 20% test.
    2. StandardScaler puts all 30 features on the same scale.
    3. Build the network. Each hidden layer has
       kernel_regularizer=l2(0.001), which adds the L2 penalty for that
       layer's weights:
         Dense(64) -> Dense(32) -> Dense(16) -> Dense(1, sigmoid)
       Sigmoid gives a value from 0 to 1 (probability of benign).
    4. Compile with binary_crossentropy (used for 2 classes).
    5. Train for 20 epochs, keeping 20% of training data aside for
       validation, so we can watch for overfitting.
    6. Print test accuracy and plot the accuracy and loss graphs.
       If training and validation curves stay close together, the
       model is not overfitting.

HOW TO RUN (Windows):
    1. Save this code as exp5.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow scikit-learn matplotlib
    6. Run the code      :  python exp5.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - A graph window opens; close it to end the program

CONCLUSION:
    A neural network with L2 Regularization was implemented
    successfully on the Breast Cancer dataset. It classified benign and
    malignant tumours with high accuracy (about 95-97%), and the training
    and validation curves stayed close, showing that L2 Regularization
    helps reduce overfitting and improves generalization.
"""
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.regularizers import l2
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. Load Breast Cancer Dataset
data = load_breast_cancer()
X = data.data       # 30 features per patient
y = data.target     # 0 = malignant, 1 = benign
print("Dataset Shape :", X.shape)

# 2. Split Dataset (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 3. Normalize Features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 4. Build Neural Network with L2 Regularization on every hidden layer
model = Sequential([
    Input(shape=(30,)),
    Dense(64, activation='relu', kernel_regularizer=l2(0.001)),
    Dense(32, activation='relu', kernel_regularizer=l2(0.001)),
    Dense(16, activation='relu', kernel_regularizer=l2(0.001)),
    Dense(1, activation='sigmoid')     # output: probability of benign
])

# 5. Compile Model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()

# 6. Train Model (20% of training data used for validation)
history = model.fit(X_train, y_train, epochs=20, batch_size=16, validation_split=0.2)

# 7. Evaluate Model on test data
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print("\nTest Loss :", loss)
print("Test Accuracy :", accuracy)

# 8. Plot Accuracy and Loss side by side
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title("Accuracy")
plt.xlabel("Epoch")
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title("Loss")
plt.xlabel("Epoch")
plt.legend()

plt.tight_layout()
plt.show()
