r"""
Experiment 7: Convolutional Neural Network (CNN) on Fashion-MNIST

AIM:
    To build and train a Convolutional Neural Network using TensorFlow
    and Keras for classifying fashion images from the Fashion-MNIST
    dataset.

THEORY (in simple words):
    - A normal ANN flattens the image into one long line of numbers, so
      it loses the information about which pixels are NEXT to each
      other. A CNN keeps the image as 2D, so it can find shapes.
    - CNN architecture (layers in order):

        Input image (28x28x1)
             |
        CONVOLUTION  : small filters (3x3) slide over the image and
             |         detect features like edges, lines and corners.
             |         Output = "feature maps".
        RELU         : keeps only positive values (adds non-linearity).
             |
        MAX POOLING  : takes the biggest value from each 2x2 block.
             |         Makes the feature maps smaller and faster to
             |         process, while keeping the important parts.
        (Conv + Pool again: learns bigger shapes like collars, soles)
             |
        FLATTEN      : turns the feature maps into one long line.
             |
        DENSE        : fully connected layer that combines the features.
             |
        OUTPUT (Softmax, 10 neurons): probability of each class.

    - Fashion-MNIST: 70,000 grey 28x28 images of 10 clothing types.

HOW THE CODE WORKS:
    1. Load Fashion-MNIST and divide pixels by 255.
    2. Reshape to (28, 28, 1): CNNs need a "channel" value
       (1 = greyscale, 3 = colour).
    3. Build the CNN:
         Conv2D(32) -> MaxPool -> Conv2D(64) -> MaxPool
         -> Flatten -> Dense(64) -> Dense(10, softmax)
    4. Compile with Adam + sparse_categorical_crossentropy and train
       for 5 epochs (10% of training data kept for validation).
    5. Print test accuracy, predict the first test image, print the
       predicted and actual class names, and show the image.

HOW TO RUN (Windows):
    1. Save this code as exp7.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow matplotlib
    6. Run the code      :  python exp7.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads Fashion MNIST, ~30 MB)
      - Takes about 1-2 minutes
      - An image window opens; close it to end the program

CONCLUSION:
    A Convolutional Neural Network was built and trained successfully on
    Fashion-MNIST. Using convolution and pooling layers to learn image
    features, it reached about 90% test accuracy, which is better than
    the plain MLP of Experiment 2. This shows why CNNs are preferred for
    image classification.
"""
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.datasets import fashion_mnist

# 1. Load Fashion-MNIST dataset
(x_train, y_train), (x_test, y_test) = fashion_mnist.load_data()

# 2. Normalize pixel values (0-255 -> 0-1)
x_train = x_train / 255.0
x_test = x_test / 255.0

# 3. Reshape images for CNN: (number of images, 28, 28, 1 channel)
x_train = x_train.reshape(-1, 28, 28, 1)
x_test = x_test.reshape(-1, 28, 28, 1)

# 4. Class labels (index 0 to 9)
class_names = ["T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
               "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"]

# 5. Build CNN model
model = Sequential([
    Input(shape=(28, 28, 1)),
    Conv2D(32, (3, 3), activation="relu"),   # 32 filters find simple features
    MaxPooling2D((2, 2)),                    # shrink feature maps by half
    Conv2D(64, (3, 3), activation="relu"),   # 64 filters find bigger shapes
    MaxPooling2D((2, 2)),
    Flatten(),                               # feature maps -> one line
    Dense(64, activation="relu"),
    Dense(10, activation="softmax")          # 10 clothing classes
])
model.summary()

# 6. Compile the model
model.compile(optimizer="adam",
              loss="sparse_categorical_crossentropy",
              metrics=["accuracy"])

# 7. Train the model
model.fit(x_train, y_train, epochs=5, validation_split=0.1)

# 8. Evaluate the model
test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=0)
print("\nTest Accuracy:", test_accuracy)

# 9. Predict the first test image
prediction = model.predict(x_test[:1], verbose=0)
predicted_class = prediction.argmax()      # class with highest probability
actual_class = y_test[0]

print("Predicted Class:", class_names[predicted_class])
print("Actual Class:", class_names[actual_class])

# 10. Display the image with its prediction
plt.imshow(x_test[0].reshape(28, 28), cmap="gray")
plt.title("Predicted: " + class_names[predicted_class])
plt.axis("off")
plt.show()
