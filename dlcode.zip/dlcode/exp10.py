r"""
Experiment 10: LSTM Network on the Iris Dataset

AIM:
    To implement an LSTM network for sequence modelling and prediction
    using the built-in Iris dataset.

THEORY (in simple words):
    - A SimpleRNN has a short memory. In long sequences the gradients
      become very small (VANISHING GRADIENT problem), so it forgets the
      early steps.
    - LSTM (Long Short-Term Memory) is a special RNN that can remember
      information for a long time. It has a CELL STATE (long-term
      memory) and 3 GATES that decide what to keep:
        Forget gate : what old information to throw away.
        Input gate  : what new information to store.
        Output gate : what part of the memory to output now.
      Each gate uses a sigmoid (0 = block, 1 = let through).
    - Iris dataset: 150 flowers, 4 measurements each (sepal length,
      sepal width, petal length, petal width), 3 classes (Setosa,
      Versicolor, Virginica).
    - Iris is NOT really sequence data. Here we treat the 4 measurements
      as a sequence of 4 time steps, just to practise how an LSTM is
      built. A simple Dense network would also work fine for Iris.

HOW THE CODE WORKS:
    1. Load Iris and scale the features with StandardScaler.
    2. Reshape X to (150 samples, 4 time steps, 1 feature), because
       LSTM layers need 3D input.
    3. One-hot encode labels with to_categorical:
           0 -> [1, 0, 0],  1 -> [0, 1, 0],  2 -> [0, 0, 1]
    4. Split 80% train / 20% test.
    5. Build: LSTM(32) -> Dense(3, softmax). Softmax (not sigmoid) is
       used because there are 3 classes and we want probabilities that
       add up to 1. Loss = categorical_crossentropy (for one-hot labels).
    6. Train for 50 epochs, print test accuracy, show 5 predictions, and
       plot accuracy/loss graphs.

HOW TO RUN (Windows):
    1. Save this code as exp10.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow numpy scikit-learn matplotlib
    6. Run the code      :  python exp10.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - A graph window opens; close it to end the program

CONCLUSION:
    An LSTM network was implemented successfully on the Iris dataset by
    treating the 4 features as a short sequence. It classified the
    flowers with high accuracy (about 90-100%), showing how LSTMs use
    gates and memory to model sequences.
"""
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, LSTM, Dense

# 1. Load built-in Iris dataset
iris = load_iris()
X = iris.data      # 4 features
y = iris.target    # 3 classes: 0, 1, 2

print("Total samples:", len(X))
print("Feature names:", iris.feature_names)
print("Class names:", iris.target_names)

# 2. Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 3. Reshape as a sequence: (samples, time_steps=4, features=1)
X_seq = X_scaled.reshape(X_scaled.shape[0], X_scaled.shape[1], 1)

# 4. One-hot encode target labels
y_encoded = to_categorical(y)

# 5. Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_seq, y_encoded, test_size=0.2, random_state=42)

# 6. Build LSTM model
model = Sequential([
    Input(shape=(4, 1)),
    LSTM(32, activation='tanh'),       # reads the 4 features as a sequence
    Dense(3, activation='softmax')     # probability of each flower class
])
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

# 7. Train the model
history = model.fit(X_train, y_train, epochs=50, batch_size=8, validation_split=0.2)

# 8. Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)
print("\nTest Loss    :", loss)
print("Test Accuracy:", accuracy)

# 9. Predict on 5 test samples
predictions = model.predict(X_test, verbose=0)
for i in range(5):
    predicted_class = iris.target_names[np.argmax(predictions[i])]
    actual_class = iris.target_names[np.argmax(y_test[i])]
    print("Actual:", actual_class, " | Predicted:", predicted_class)

# 10. Plot accuracy and loss
plt.figure(figsize=(10, 4))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Accuracy over Epochs')
plt.xlabel('Epoch')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Loss over Epochs')
plt.xlabel('Epoch')
plt.legend()

plt.tight_layout()
plt.show()
