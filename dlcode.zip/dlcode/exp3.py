r"""
Experiment 3: Forward and Backward Propagation on CIFAR-10

AIM:
    To implement Forward and Backward Propagation using TensorFlow and
    Keras for classifying images from the CIFAR-10 dataset.

THEORY (in simple words):
    - FORWARD PROPAGATION = making a prediction.
        Input image -> hidden layers -> output layer -> predicted class.
    - LOSS = how wrong the prediction is (big loss = very wrong).
    - BACKWARD PROPAGATION = learning from the mistake.
        The error is sent back through the network to find how much
        each weight caused it (these amounts are called GRADIENTS).
    - WEIGHT UPDATE: each weight moves a little in the direction that
      lowers the loss:
            W(new) = W(old) - learning_rate * gradient
    - This is repeated for every batch, in every epoch, so the loss goes
      down and the predictions get better.
    - tf.GradientTape "records" the forward pass so TensorFlow can
      automatically calculate the gradients for the backward pass.
    - CIFAR-10: 60,000 small colour images (32 x 32 x 3) in 10 classes:
      airplane, car, bird, cat, deer, dog, frog, horse, ship, truck.

HOW THE CODE WORKS:
    1. Load CIFAR-10 and divide pixels by 255 (normalization).
    2. Build a simple network: Flatten -> Dense(128) -> Dense(64) ->
       Dense(10, softmax).
    3. Instead of model.fit(), we write the training loop ourselves so
       each step is visible:
         - take a small batch of 64 images
         - forward propagation : predictions = model(images)
         - loss calculation    : compare predictions with true labels
         - backward propagation: tape.gradient() finds the gradients
         - weight update       : optimizer.apply_gradients()
    4. Print the loss after each epoch (it should go down).
    5. Test on unseen images and print the accuracy.
    Note: a plain Dense network is not the best for colour photos, so
    accuracy is around 45-50%. That is expected; a CNN (Experiment 7)
    does better on images.

HOW TO RUN (Windows):
    1. Save this code as exp3.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow numpy
    6. Run the code      :  python exp3.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads CIFAR-10, ~170 MB)
      - Takes a few minutes (5 epochs on 50,000 images)

CONCLUSION:
    Forward propagation produced predictions for the CIFAR-10 images and
    backward propagation used the gradients of the loss to update the
    weights. The loss went down over the epochs, showing that the
    network learned image patterns and improved its classification.
"""
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Flatten, Dense

# 1. Load CIFAR-10 dataset and normalize (0-255 -> 0-1)
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0

# 2. Build Neural Network
model = Sequential([
    Input(shape=(32, 32, 3)),          # 32 x 32 colour image
    Flatten(),                         # -> 3072 numbers
    Dense(128, activation='relu'),
    Dense(64, activation='relu'),
    Dense(10, activation='softmax')    # 10 classes
])

# 3. Define Loss Function and Optimizer
loss_function = tf.keras.losses.SparseCategoricalCrossentropy()
optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)

epochs = 5
batch_size = 64

print("Training Started...\n")

# 4. Training loop
for epoch in range(epochs):
    for i in range(0, len(x_train), batch_size):
        # Take one small batch of images and labels
        x_batch = x_train[i:i + batch_size]
        y_batch = y_train[i:i + batch_size]

        with tf.GradientTape() as tape:
            # Forward Propagation: make predictions
            predictions = model(x_batch, training=True)
            # Loss Calculation: how wrong are we?
            loss = loss_function(y_batch, predictions)

        # Backward Propagation: find gradients of loss for every weight
        gradients = tape.gradient(loss, model.trainable_variables)

        # Weight Update: move weights to reduce the loss
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))

    print("Epoch:", epoch + 1, " Loss:", round(float(loss), 4))

print("\nTraining Completed Successfully.")

# 5. Test the model on unseen images
predictions = model.predict(x_test, verbose=0)
predicted_classes = np.argmax(predictions, axis=1)    # pick the highest probability
accuracy = np.mean(predicted_classes == y_test.flatten())
print("Test Accuracy:", round(accuracy * 100, 2), "%")
