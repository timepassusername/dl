r"""
Experiment 1: Simple Artificial Neural Network (ANN) on MNIST

AIM:
    To implement a simple Artificial Neural Network using TensorFlow and
    Keras for classifying handwritten digits (0-9) from the MNIST dataset.

THEORY (in simple words):
    - An Artificial Neural Network copies the idea of the human brain.
      It is made of small units called NEURONS.
    - Each neuron: takes inputs -> multiplies by weights -> adds them up
      -> applies an activation function -> gives an output.
    - Layers:
        Input layer  : receives the data (here, image pixels).
        Hidden layer : learns patterns (curves, lines of the digits).
        Output layer : gives the final answer (which digit 0-9).
    - MNIST: 70,000 grey images (28 x 28 pixels) of handwritten digits.
      60,000 are used for training and 10,000 for testing.
    - Important words:
        ReLU     : activation for hidden layers; keeps positive values,
                   turns negatives into 0.
        Softmax  : activation for the output; turns scores into
                   probabilities that add up to 1.
        Adam     : optimizer, the method that updates the weights.
        Epoch    : one full pass over all training images.
        Accuracy : % of images predicted correctly.

HOW THE CODE WORKS:
    1. Load MNIST (Keras downloads it automatically the first time).
    2. Normalize: divide pixels by 255 so values are 0 to 1
       (small numbers make training faster and more stable).
    3. Build the model:
         Flatten       -> turns the 28x28 image into 784 numbers
         Dense(128)    -> hidden layer with 128 neurons (ReLU)
         Dense(10)     -> output layer, one neuron per digit (Softmax)
    4. Compile with Adam optimizer and
       sparse_categorical_crossentropy loss (used when labels are
       plain numbers like 0, 1, 2 ... 9).
    5. Train for 10 epochs, then test on unseen images.

HOW TO RUN (Windows):
    1. Save this code as exp1.py
    2. Open Command Prompt in that folder
       (type cmd in the File Explorer address bar and press Enter)
    3. Create a venv     :  python -m venv venv
    4. Activate the venv :  venv\Scripts\activate
                            (you will see (venv) at the start of the line)
    5. Install libraries :  pip install tensorflow
    6. Run the code      :  python exp1.py
    Note:
      - TensorFlow works on Python 3.9 to 3.12 (check: python --version)
      - First run needs internet (downloads MNIST, ~11 MB)
      - Takes about 30 seconds

CONCLUSION:
    A simple Artificial Neural Network was implemented successfully
    using TensorFlow and Keras. After training, it classified handwritten
    digits from the MNIST test set with high accuracy (about 97-98%).
"""
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Flatten, Dense

# 1. Load MNIST dataset
(X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()

# 2. Normalize the data (pixel values 0-255 -> 0-1)
X_train = X_train / 255.0
X_test = X_test / 255.0

# 3. Build the model
model = Sequential([
    Input(shape=(28, 28)),            # each image is 28 x 28 pixels
    Flatten(),                        # 28 x 28 -> 784 numbers in a line
    Dense(128, activation='relu'),    # hidden layer
    Dense(10, activation='softmax')   # output: probability of each digit
])

# 4. Compile the model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# 5. Train the model
model.fit(X_train, y_train, epochs=10, batch_size=32)

# 6. Evaluate the model on test images it has never seen
loss, accuracy = model.evaluate(X_test, y_test)
print("Test Accuracy:", accuracy)
print("Test Loss:", loss)
